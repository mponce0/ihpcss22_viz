os.getcwd()   # get the current directory}

os.chdir("/Users/marcelo/Downloads/datasets/scripts")

# os.chdir("C:\Users\marcelo\Desktop\datasets")    # Windows example

Source("scriptName.py")
