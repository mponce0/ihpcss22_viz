# this is printView.py
print GetView3D()   # print all its attributes of the current view
# GetView3D().viewNormal   # can also print a single attribute
